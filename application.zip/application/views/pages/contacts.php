<div class="content container-fluid">
application\views\pages\contacts.php
</div>