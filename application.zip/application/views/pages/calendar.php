<div class="content container-fluid">
application\views\pages\calendar.php
</div>