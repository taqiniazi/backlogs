<div class="content container-fluid">
    application\views\pages\user-dashboard.php
</div>