<h1><?php echo $network['name']; ?></h1>

