<div class="content container-fluid">
application\views\pages\email.php
</div>