<div class="content container-fluid">
application\views\pages\chat.php
</div>