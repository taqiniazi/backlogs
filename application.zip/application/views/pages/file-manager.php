<div class="content container-fluid">
application\views\pages\file-manager.php
</div>