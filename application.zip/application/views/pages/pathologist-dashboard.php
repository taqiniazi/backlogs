<div class="content container-fluid">
    application\views\pages\pathologist-dashboard.php
</div>