<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="row">
						<div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
                        <table><tr><td>
                        <div class="col-md-4 text-center">
                            <a href="<?php echo base_url('index.php/admin/record_tracking_view/laboratory/'); ?>">
                                <img src="<?php echo base_url('assets/img/Laboratory.jpg'); ?>">
                            </a> 
                        </div></td><td>
                       <!-- <div class="col-md-4 text-center">
                            <a href="<?php echo base_url('index.php/admin_tracking/SearchTracking/search_tracking/'); ?>">
                                <img src="<?php echo base_url('assets/img/Central-Admin.jpg'); ?>">
                            </a>
                        </div>--></td><td>
                        <div class="col-md-4 text-center">
                            <a href="<?php echo base_url('index.php/admin/record_tracking_view/reporting/'); ?>">
                                <img src="<?php echo base_url('assets/img/Reporting.jpg'); ?>">
                            </a>
                        </div></td></tr></table>
                    </div>
                </div>
           