<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="col-md-12">
    <div class="well">
        <a href="javascript:history.back();"><button class="btn btn-danger"><< Go Back</button></a>
        <hr>
        <p class="lead">You Do Not Have Permission To View This Page!</p>
    </div>
</div>
